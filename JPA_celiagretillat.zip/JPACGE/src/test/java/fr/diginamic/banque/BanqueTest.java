package fr.diginamic.banque;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BanqueTest {

	@Test
	public void testAddBanque() {
		
	}


}
